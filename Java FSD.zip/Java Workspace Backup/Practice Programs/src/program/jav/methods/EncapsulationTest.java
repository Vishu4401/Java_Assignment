package program.jav.methods;

public class EncapsulationTest {

}
