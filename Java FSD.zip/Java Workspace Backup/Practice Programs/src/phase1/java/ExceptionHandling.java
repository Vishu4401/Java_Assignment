package phase1.java;

public class ExceptionHandling {
	public static void main(String[] args) {
		int num1, num2, num3;
		
		num1 = 40;
		num2 = 0;
		
		try {
			num3 = num1/num2;
			System.out.println("The result of num3 is: " +num3);
		}
		catch(ArithmeticException ae) {
			System.out.println("The numbers cannot be divided by zero");
			System.out.println(ae.getMessage());
		}
		
		//This code will be helpful if the user entered catch method does not match the the exception type
		catch(Exception ae1) {
			System.out.println("I am before the subclass exception");
		}
		
		finally {
			num3 = num1 + num2;
			System.out.println("The result of addition is: " +num3);
			System.out.println("This block gets always executed");
		}
	}

}
