package phase1.java;

import java.io.IOException;
import java.util.Scanner;

public class ExceptionHandlingArea {
	static int rect(int length , int breadth) throws IOException {
		if(length > breadth) {
			throw new IOException("Length is greater than breadth");
		}
		else {
			System.out.println("Both length and breadth parameters are correct");
		}
		return length * breadth;
	}
	
	public static void main(String[] args) {
		int area = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Lenght: ");
		int length = sc.nextInt();
		
		System.out.println("Enter the Breadth: ");
		int breadth = sc.nextInt();
		
		try {
			area = rect(length, breadth);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Area of rectangle is: " +area);
	}

}
