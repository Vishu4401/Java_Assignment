package phase1.java;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.util.Scanner;
public class FileMultiple {


	public static void main(String args[]) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the contents of Day-1 to be added: ");
		String data1 = sc.nextLine();
		System.out.println("Enter the contents of Day-2 to be added: ");
		String data2 = sc.nextLine();
		
//		String data = "This is the data in the output file";
//		
		try {
			// Step 1: Creates a Writer using FileWriter
			FileWriter output = new FileWriter("C:\\Users\\Vishwa\\Desktop\\Mphasis\\Simplilearn Java Technology\\phase1.txt");
			
			output.append(data1);
			System.out.println("Data of Day-1 is written in to the file");
			
			output.write(data2);
			System.out.println("Data of Day-2 is written in to the file");
			
//			System.out.println(output);
			
			// Step 3: Closes the writer
//			String str = Files.readString();
			
			System.out.println("Enter the Day-3 contents: ");
			String data3 = sc.nextLine();
			
			System.out.println(data1);
			System.out.println(data2);

			
			output.append(data3);
			System.out.println("Day-3 contents have been written");
			System.out.println(data3);

			output.close();
		}
		catch (Exception e) {
			e.getStackTrace();
		}
	}
}
