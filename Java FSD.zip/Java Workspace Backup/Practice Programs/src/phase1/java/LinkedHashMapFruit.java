package phase1.java;


import java.util.LinkedHashMap;
import java.util.Map;
public class LinkedHashMapFruit {
	
  public static void main(String[] args) {
        
	    Map<Integer, String> linkedHashMap = new LinkedHashMap<Integer, String>();
        
        linkedHashMap.put(1, new String("Apple"));
        linkedHashMap.put(2, new String("Banana"));
        linkedHashMap.put(3, new String("Watermelon"));
        linkedHashMap.put(4, new String("Papaya"));
        linkedHashMap.put(5, new String("Muskmelon"));
        linkedHashMap.put(6, new String("Chikku"));
        linkedHashMap.put(7, new String("Dragon Fruit"));
        linkedHashMap.put(8, new String("Cherry"));
        linkedHashMap.put(9, new String("Cantaloupe"));
        linkedHashMap.put(10, new String("Blueberry"));
        
        
        
        System.out.println("Contents of LinkedHashMap : " + linkedHashMap);
        System.out.println("\nValues of map after iterating over it : ");
        
        for (Integer key : linkedHashMap.keySet()) {
            System.out.println(key + " :\t" + linkedHashMap.get(key));
        }
        System.out.println("Removing the 4th fruit by value: " +linkedHashMap.remove("Papaya"));        
        System.out.println("Removing the 7th fruit by key : " +linkedHashMap.remove(7));
        System.out.println("Contents after removing are:  " +linkedHashMap);
        
        System.out.println("\nLinkedHashMap contains 4 as key? : " + linkedHashMap.containsKey(4));
        System.out.println("LinkedHashMap contains Banana as value? : " + linkedHashMap.containsValue("Banana"));
        System.out.println("LinkedHashMap contains Apple as value? : " + linkedHashMap.containsValue("Apple"));
        
        System.out.println("\nHashcode for Map: " + linkedHashMap.hashCode());

       
        linkedHashMap.clear();
        System.out.println("\nContent of LinkedHashMap after clearing: " + linkedHashMap);
    }
}
