package phase1.java;

import java.io.IOException;
import java.util.Scanner;

public class ExceptionSalary {
	static int person(int salary) throws IOException{
		if(salary < 2100) {
			System.out.println("You need to work hard");
		}
		else if(salary < (5000)) {
			System.out.println("Your Salary is somehow good");
		}
		else if(salary < 9000) {
			System.out.println("Your salary is very good");
		}
		return salary;
	}
	
	public static void main(String[] args) {
		int salary = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Salary: ");
		int person = sc.nextInt();
		
		try {
			salary = person(salary);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Salary is: " +person);
	}
}


