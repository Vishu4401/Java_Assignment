package phase1.java;

import java.util.HashSet;

class Hashset{
	public static void main(String[] args){
		
		//LinkedHashSet<String> hs=new LinkedHashSet<String>();
		HashSet<Integer> hs=new HashSet<Integer>();
		
		hs.add(24);
		hs.add(56);
		
		HashSet<Float> hs1 = new HashSet<Float>();
		
		hs1.add(25.87f);
		hs1.add(39.24f);
		
		HashSet<Character> hs2 = new HashSet<Character>();
		
		hs2.add('V');
		hs2.add('S');
		
		HashSet<Boolean> hs3 = new HashSet<Boolean>();
		hs3.add(true);
				
		System.out.println("Hashset of Integer is "+hs);
		System.out.println("Hashset of Float is "+hs1);
		System.out.println("Hashset of Character is "+hs2);
		System.out.println("Hashset of Boolean is "+hs3);
		
		System.out.println("Size of Hashset is "+ hs.size());
		System.out.println("Size of Hashset is "+ hs1.size());
		System.out.println("Size of Hashset is "+ hs2.size());
		System.out.println("Size of Hashset is "+ hs3.size());
		
		System.out.println("Does hashset contains this 'u' element  " + hs.contains("u"));		
		System.out.println("is hashset empty  " + hs.isEmpty());
		System.out.println("remove the element "+hs.remove("i"));
		
		
	    hs.clear();
	    System.out.println("get class  " +hs.getClass());
		
	    System.out.println("is hashset empty  " +hs.isEmpty());
	    
	    
		
	}
}