package phase1.java;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Vector;

public class LinkedListProgram {
    public static void main(String a[]){
    	
    	int a1 = 12;
    	
        LinkedList<String> ll = new LinkedList<String>();
        
        ll.addFirst("January");
        
        ll.add("May");
        ll.add("June");
        ll.add("July");
        ll.add("August");
        ll.add(1, "April");
        ll.add("November");
        ll.add("December");
        
        //ll.add(a1);    // wrapping of primitive is done automatically to convert to Integer object
                
//        ll.addFirst("January");
        ll.add(1, "March");
        ll.add(1, "February");
        ll.add(8, "September");
        ll.add(9, "October");
//        ll.remove(3);
                 
        Iterator itr=ll.iterator();
        System.out.println("The correct order of the Months is: \n");
        while(itr.hasNext()) {
        System.out.println(""+ itr.next());
        }
       
        System.out.println(ll);
        
        ll.set(1, "February");
        
//        ListIterator<E> itra = evenList.listIterator();
//        for(int i = 0; itr.hasNext(); i++) {
//        	if(i%2 == 0) {
//        		itr.remove();
//        		System.out.println("The Even months are: \n");
//        		itr.next();
//        	}
//        	i++;
//        }
//        return 
        System.out.println("Size of the linked list: "+ll.size());
        System.out.println("Is LinkedList empty? "+ll.isEmpty());
        System.out.println("Does LinkedList contains 'September'? "+ll.contains("September"));
               
        
        Vector<String> v = new Vector<String>();
        v.add("Jaipur");
        v.add("Delhi");
        v.add("Mumbai");
        
        Iterator itr1=v.iterator();
        while(itr1.hasNext()) {
        System.out.println("Vector is"+ itr1.next());
        }
        
    }
}