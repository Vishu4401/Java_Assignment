package phase1.java;

//Example illustrates multiple threads are executing on the same Object at same time without synchronization.
import java.io.*;

class Line
{
	// if multiple threads(trains) will try to access this unsynchronized method, they all will get it. So there is chance that Object's state will be corrupted 
	//put synchronized and run
	synchronized public void getLine()                     
	{
		int n1 = 4, n2 = 6, fact = 0, fact1, fact2;
		fact1 = fact*n1;
		fact2 = fact*n2;
		
		try
			{
				System.out.println("Factorial of fact1 is: " +fact1);
				Thread.sleep(400);
				System.out.println("Factorial of fact2 is: " +fact2);
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
	}
}
//
class Train extends Thread
{
	// reference to Line's Object.
	Line line;

	Train(Line line)
	{
		this.line = line;
	}

	@Override
	public void run()
	{
		line.getLine();
	}
}

public class ThreadProcess
{
	public static void main(String[] args)
	{
		// Object of Line class that is shared among the threads.
		Line obj = new Line();

		// creating the threads that are sharing the same Object.
		Train train1 = new Train(obj);
		Train train2 = new Train(obj);
		
		train1.setName("Process 1");
		train2.setName("Process 2");

		// threads start their execution.
		train2.start();
		train1.start();
	}
}
