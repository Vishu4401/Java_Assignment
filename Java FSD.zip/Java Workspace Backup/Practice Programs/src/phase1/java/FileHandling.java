package phase1.java;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class FileHandling {

	public static void main(String args[]) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the contents to be added in the file: ");
		String data = sc.next();
		
//		String data = "This is the data in the output file";
//		
		try {
			// Step 1: Creates a Writer using FileWriter
			FileWriter output = new FileWriter("C:\\Users\\Vishwa\\Desktop\\Mphasis\\Simplilearn Java Technology\\phase1.txt");
			
			output.append(data);
			System.out.println("Data is written to the file.");
			
			// Step 3: Closes the writer
			output.close();
		}
		catch (Exception e) {
			e.getStackTrace();
		}
	}
}
