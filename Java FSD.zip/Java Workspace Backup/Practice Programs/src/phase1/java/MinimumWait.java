package phase1.java;

class Customer{  
int T1 = 5000, T2 = 4000, T3 = 10000, T4 = 20000;
int amount=10000;   
  
	synchronized void withdraw(int amount){  
	System.out.println("going to withdraw...");  
	  
		if(this.amount<amount)
		{  
		System.out.println("Less balance; waiting for deposit...");  	
		try{
			wait();
		   }
		catch(Exception e){}  
		}  
		
		this.amount-=amount;
		this.amount-=T2;
		this.amount-=T1;
		this.amount-=T3;
		System.out.println("withdraw completed...the lefft over amount is"+ this.amount);  
	}  
  
	synchronized void deposit(int amount){  
		System.out.println("going to deposit...");  
		this.amount+=amount;  
		
		System.out.println("deposit completed... " + this.amount);  
		notify();  //unlocking of thread
	}  
}  
  
public class MinimumWait{  
	public static void main(String args[]){  
		final Customer c=new Customer();  
		
		new Thread(){                 // anonymous class
		  public void run()
		  {
			c.withdraw(2000);
		  }  
		}.start();  
		
		new Thread(){  
		  public void run()
		   {
			 c.deposit(2000);
//			 c.deposit(T4);
		   }  
		}.start();    
	}}