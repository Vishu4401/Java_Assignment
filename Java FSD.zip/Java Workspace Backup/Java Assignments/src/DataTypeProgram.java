package phase1.mphasis;

public class DataTypeProgram {

	public static void main(String[] args) {
		int age = 56;
		float f = 56.78f;
		char c = 'V';
		long l = 475754875896744566L;
		double d = 5524.6512;
		boolean B = true;
		byte b = 34;
		short s = 23;
		
		System.out.println("This is my DataType Program");
		System.out.println("Float value is: " + f);
		System.out.println("Integer value is: " + age);
		
		System.out.println("Char value is: " + c);
		System.out.println("Long value is: " + l);
		System.out.println("Double value is: " + d);
		System.out.println("Boolean value is: " + B);
		System.out.println("Byte value is: " + b);
		System.out.println("Short value is: " + s);




	}

}
